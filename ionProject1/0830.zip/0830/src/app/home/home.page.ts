import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  gasolina = 0;
  etanol = 0;
  resultado = 0;
  resposta = 0;

  selecoes = [
    'brasil.png',
    'portugal.png'
  ];

  imagem = 'inicio.jpg';

  login = '';
  senha = '';

  constructor() {}

  custobeneficio(): void{
    this.resultado = this.etanol / this.gasolina;
  }

  trocar(indice: number): void{
    this.imagem = this.selecoes[indice];
  }


}
